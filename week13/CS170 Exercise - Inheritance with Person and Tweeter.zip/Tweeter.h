// Name       : TODO
// Course     : CS170
// Term & Year: Spring 2021
#pragma once

#include "Person.h"

// TODO Declare and Define Tweeter class