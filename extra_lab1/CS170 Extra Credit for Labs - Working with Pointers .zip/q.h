// @todo: Add a file-level documentation header as explained in Lab 2 specs ...

// @todo: Provide function-level documentation header for each function 
// as explained in Assignment 2 specs ...
// It is important that you provide a function-level documentation header in
// this [header] file since this file is what you would provide to your
// clients and other users ...

// @todo: Now, provide the declaration or prototype of the functions 
// read_total_count, read_3_numbers, swap, sort_3_numbers, and 
// maintain_3_largest
