#pragma once

#include <exception>

namespace HLP2
{

    class SubscriptError
    {
        static constexpr const char* ERROR_MESSAGE = "array out of bounds exception";
    };


}
