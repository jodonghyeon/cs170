// TODO1: add file header documentation!!!

#include "q.h" // included because q.c requires access to ASCII_COUNT
// TODO2: include other C standard library headers. for reasons 
// explained in previous assignments/labs, think carefully about 
// the need to add an include file before you do so ...

// TODO3: define functions encrypt and decrpyt ...
