// make sure to have a file-level Doxygen documentation block!!!
// read the specs to know which standard library headers cannot be included!!!