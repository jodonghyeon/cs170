#pragma once

namespace HLP2
{
    unsigned rand();
    void     srand(unsigned, unsigned);
    int      random(int low, int high);
}
