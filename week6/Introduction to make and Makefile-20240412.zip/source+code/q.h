#ifndef Q_H // header guard
#define Q_H

#include <vector> // for interface of class std::string

namespace hlp2 {

bool check_distinct(std::vector<int> cont);  

} // end of namespace hlp2

#endif // end of header guard
