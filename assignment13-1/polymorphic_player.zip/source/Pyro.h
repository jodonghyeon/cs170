#pragma once

namespace HLP2
{

}
