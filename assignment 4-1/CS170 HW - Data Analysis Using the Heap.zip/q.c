// TODO: File documentation block required

#include "q.h" // we're including q.h here because we want to apply the DRY principle [see specs for additional info]

// TODO: Include all necessary C standard library headers 

// TODO: Definitions of functions declared in q.h go here ...
