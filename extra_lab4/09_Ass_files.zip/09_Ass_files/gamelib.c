// TODO: Add file-level documentation.

#include <stdio.h>
#include "gamelib.h"

// TODO: Add function-level documentation.
void del_card(Card game[], CardIndex position)
{
	// TODO
}

// TODO: Add function-level documentation.
void load_game(const char str[], Card game[])
{
	// TODO
}

// TODO: Add function-level documentation.
void play_game(Card game[])
{
	// TODO
}

// TODO: Add function-level documentation.
void display_game(const Card game[])
{
	// TODO
}
