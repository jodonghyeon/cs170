#pragma once

#define DOCTEST_CONFIG_SUPER_FAST_ASSERTS

#include "doctest.h"
