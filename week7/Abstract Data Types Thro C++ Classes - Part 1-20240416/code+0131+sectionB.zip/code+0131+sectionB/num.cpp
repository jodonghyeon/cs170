#include "num.hpp"
#include <iostream>

Num::Num() {
  //val = -999;
  // empty by design
}

Num::Num(int v) {
  val = v;
}

#if 0
Num::Num(Num const& rhs) {
  val = rhs.val;
}

Num& Num::operator=(Num const& rhs) {
  val = rhs.val;
  return *this;
}
#endif

Num& Num::operator=(int rhs) {
  val = rhs;
  return *this;
}

Num& Num::operator+=(Num const& rhs) {
  this->val += rhs.val;
  return *this;
}

Num& Num::operator+=(int rhs) {
  val += rhs;
  return *this;
}

Num operator+(Num const& lhs, Num const& rhs) {
  Num tmp{lhs};
  tmp += rhs;
  return tmp;
}

Num operator+(Num const& lhs, int rhs) {
  Num tmp{lhs};
  tmp += rhs;
  return tmp;
}

Num operator+(int lhs, Num const& rhs) {
  Num tmp{lhs};
  tmp += rhs;
  return tmp;
}

int Num::get_val() const { return this->val; }
void Num::set_val(int v) { this->val = v; }

std::ostream& operator<<(std::ostream& os, Num const& rhs) {
  os << rhs.get_val();
  return os;
}
